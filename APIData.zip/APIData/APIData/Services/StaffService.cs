﻿using APIData.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System;

namespace APIData.Services
{
    public class StaffService : IStaffService
    {
        private readonly string _apiUrl;
        public StaffService(string apiUrl)
        {
            _apiUrl = apiUrl;
        }
        public async Task<List<StaffModel>> GetStaffList()
        {
            List<StaffModel> listStaffModels = new List<StaffModel>();
            using (var client = new HttpClient())
            {
                var responseTask = await client.GetAsync(new Uri(_apiUrl));

                if (responseTask.IsSuccessStatusCode)
                {
                    string apiResponse = await responseTask.Content.ReadAsStringAsync();
                    return JsonConvert.DeserializeObject<List<StaffModel>>(apiResponse);
                }
            }
            return null;
        }
    }
}
