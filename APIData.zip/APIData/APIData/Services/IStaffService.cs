﻿using APIData.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace APIData.Services
{
    public interface IStaffService
    {
        Task<List<StaffModel>> GetStaffList();
    }
}
