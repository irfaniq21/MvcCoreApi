﻿using APIData.Models;
using APIData.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace APIData.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IStaffService _staffService;

        public HomeController(IStaffService staffService, ILogger<HomeController> logger)
        {
            _logger = logger;
            _staffService = staffService;
        }

        public async Task<IActionResult> StaffList()
        {
            List<StaffModel> listStaffModels = await _staffService.GetStaffList();
            return View(listStaffModels);
        }

    }

}
